
#include <iostream>
using namespace std;
int main()
{
    double gallons= 16;
    double miles= 316;
    
    double miles_per_gallon= miles / gallons;
    
    cout<< "The expected miles per gallon the car can run on is: " << miles_per_gallon << endl;
    
    double gallons1= 2;
    double miles1= 300;
    
    double miles_per_gallon1= miles1 / gallons1;
    
    cout<< "The manipulated miles per gallon the car can run on is: " << miles_per_gallon1 << endl;

    return 0;
}