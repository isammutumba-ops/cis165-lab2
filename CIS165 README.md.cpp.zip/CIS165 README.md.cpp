//CIS-165 Lab 2: C++ Exercises
//
//Program 1: Sum of Two Numbers
//
//Plan: Store the numbers 50 and 100 in variables, Calculate their sum and store the result in a variable
//named total, Display the value of total with clear label.
//
//To run this program; you need to go to online.gdb,select the C++ coding language, copy and paste the code,
// then run and compile it.
// 
//Testing: 
//Test 1-Assigned Values: 50 & 100
//Expected result: 150
//Actual output: the total was 150
//Match or Fix: the actual answer was 150 as expected
//
//Testing: 
//Test 2-Changed Values: 51 & 101
//Expected result: 152
//Actual output: the total was 152
//Match or Fix: the actual answer was 152 as expected
//
//Explanation:
//The program stores 50 and 100 in separate integer variables.
// It adds these two values together and stores the result in
// the variable total. The program then displays total.
// Storing the calculation in total makes the result easier to
// use and allows the program to print the result variable.
//
//Program 2: Miles Per Gallon
//
//Plan: Store 31 miles in variable, Store 16 miles in variable, Divide the miles by gallons then store that result in a variable 
//Display the mpg result
//
//Testing: 
//Test 1-Assigned Values: 312 miles & 16 gallons
//Expected result: 19.5 MPG
//Actual output: the output was 19.5 MPG
//Match or Fix: the actual answer was 19.5 as expected
//
//Testing: 
//Test 2-Changed Values: 300 miles & 2 gallons
//Expected result: 150 MPG
//Actual output: the output was 150
//Match or Fix: the actual answer was 150 as expected
//
//Explanation:
//The program calculates miles per gallon by dividing the
// number of miles by the number of gallons. The result is
// stored in a variable then it is displayed. A decimal
// data type is used so the calculation can preserve a
// fractional result. If two integer values are divided,
// C++ can perform integer division and remove the decimal
// portion of the answer.
//
//Final verification:
// Original values restored in sum.cpp: 51 and 101
//
// Original values restored in mpg.cpp: 2 and 300
//
// Final runs completed: Yes, both programs were run successfully
//
// Final verification notes:
// Both programs were run using the original values.
// The actual outputs matched the expected results.
//
//
//
//
//
//