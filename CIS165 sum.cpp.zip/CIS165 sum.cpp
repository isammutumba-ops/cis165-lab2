#include <iostream>
using namespace std;

int main() {
    double value= 50;
    double value1= 100;
    
    double sum= value + value1;
    
    cout<<"The sum of these two given values are: "<< sum << endl;
    
    double value2= 51;
    double value3= 101;
    
    double sum1= value2 + value3;
    
    cout<<"The sum of these two chosen values are: "<< sum1 << endl;
    
    return 0;
}